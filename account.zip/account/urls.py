from django.urls import path
from .views import generate_report

urlpatterns = [
 
    path('ask/',generate_report,name="AR"),
    
   
]